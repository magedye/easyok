import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useNavigate } from 'react-router-dom'
import { Card } from '@/components/shared/Card'
import { Button } from '@/components/shared/Button'
import { useTranslation } from 'react-i18next'
import { getAnalytics, generateQuery, executeQuery, getQueryHistory } from '@/services/queryService'
import { SkeletonStat, SkeletonCard } from '@/components/loading/SkeletonCard'
import { Spinner } from '@/components/loading/Spinner'
import { handleApiError } from '@/utils/errorHandler'

export const DashboardPage = () => {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const [question, setQuestion] = useState('')
  const [error, setError] = useState<string | null>(null)

  const { data: analytics, isLoading: analyticsLoading } = useQuery({
    queryKey: ['analytics'],
    queryFn: getAnalytics,
  })

  const { data: recentQueries, isLoading: historyLoading } = useQuery({
    queryKey: ['query-history-recent'],
    queryFn: () => getQueryHistory(),
  })

  const generateMutation = useMutation({
    mutationFn: async (question: string) => {
      const generated = await generateQuery({ question })
      const executed = await executeQuery({ sql: generated.sql })
      return { ...generated, ...executed }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['analytics'] })
      queryClient.invalidateQueries({ queryKey: ['query-history-recent'] })
      setQuestion('')
      setError(null)
    },
    onError: (err) => {
      const apiError = handleApiError(err)
      setError(apiError.message)
    },
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (question.trim()) {
      generateMutation.mutate(question)
    }
  }

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <div className="mb-8 text-center">
        <h1 className="text-5xl font-bold text-neutral-900 dark:text-white mb-2">
          Vanna Insight Engine
        </h1>
        <p className="text-xl text-neutral-500 dark:text-neutral-400">
          {t('slogan')}
        </p>
      </div>

      {/* Key Metrics Section */}
      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {analyticsLoading ? (
          <>
            <SkeletonStat />
            <SkeletonStat />
            <SkeletonStat />
            <SkeletonStat />
          </>
        ) : (
          <>
            <Card className="border-l-4 border-l-blue-500">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-neutral-500">{t('dashboard.stats.totalQueries')}</p>
                  <p className="text-2xl font-bold text-neutral-900 dark:text-white">
                    {analytics?.totalQueries?.toLocaleString() || 0}
                  </p>
                </div>
                <div className="text-3xl">📊</div>
              </div>
            </Card>
            <Card className="border-l-4 border-l-green-500">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-neutral-500">{t('dashboard.stats.successRate')}</p>
                  <p className="text-2xl font-bold text-neutral-900 dark:text-white">
                    {analytics ? 
                      `${((analytics.successfulQueries / analytics.totalQueries) * 100).toFixed(1)}%` : 
                      '0%'
                    }
                  </p>
                </div>
                <div className="text-3xl">✅</div>
              </div>
            </Card>
            <Card className="border-l-4 border-l-purple-500">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-neutral-500">{t('dashboard.stats.averageTime')}</p>
                  <p className="text-2xl font-bold text-neutral-900 dark:text-white">
                    {analytics?.averageExecutionTime?.toFixed(0) || 0}ms
                  </p>
                </div>
                <div className="text-3xl">⚡</div>
              </div>
            </Card>
            <Card className="border-l-4 border-l-orange-500">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-neutral-500">Successful Queries</p>
                  <p className="text-2xl font-bold text-neutral-900 dark:text-white">
                    {analytics?.successfulQueries?.toLocaleString() || 0}
                  </p>
                </div>
                <div className="text-3xl">✓</div>
              </div>
            </Card>
          </>
        )}
      </section>

      {/* Quick Actions Section */}
      <section>
        <h2 className="text-3xl font-bold text-neutral-900 dark:text-white mb-4">{t('common.quickActions')}</h2>
        <Card>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Button className="w-full" variant="primary">
              {t('dashboard.quickActions.tryExample')}
            </Button>
            <Button className="w-full" variant="secondary" onClick={() => navigate('/history')}>
              {t('dashboard.quickActions.viewHistory') || 'View History'}
            </Button>
            <Button className="w-full" variant="secondary" onClick={() => navigate('/schema')}>
              {t('dashboard.quickActions.browseSchema') || 'Browse Schema'}
            </Button>
            <Button className="w-full" variant="secondary" onClick={() => navigate('/settings')}>
              {t('common.settings') || 'Settings'}
            </Button>
          </div>
        </Card>
      </section>

      {/* Main Content Grid */}
      <section className="grid gap-4 lg:grid-cols-3">
        <Card title={t('query.title') || 'Ask a Question'} description={t('dashboard.queryInput.placeholder') || 'Generate SQL from natural language'}>
          {error && (
            <div className="mb-3 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-900/50 rounded-md">
              <p className="text-sm text-red-900 dark:text-red-300">{error}</p>
            </div>
          )}
          <form onSubmit={handleSubmit} className="space-y-3">
            <textarea
              placeholder={t('dashboard.queryInput.placeholder') || 'e.g., Show me total sales by region'}
              className="w-full px-3 py-2 border border-neutral-300 dark:border-neutral-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-neutral-800 dark:text-white text-sm"
              rows={4}
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              disabled={generateMutation.isPending}
            />
            <Button className="w-full" variant="primary" type="submit" disabled={generateMutation.isPending || !question.trim()}>
              {generateMutation.isPending ? (
                <span className="flex items-center justify-center gap-2">
                  <Spinner size="sm" />
                  Generating...
                </span>
              ) : (
                t('dashboard.queryInput.submit') || 'Generate SQL'
              )}
            </Button>
          </form>
        </Card>
        <Card title={t('common.activeOperations')}>
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <span className="text-sm">{t('common.running')}</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <span className="text-sm">{t('common.running')}</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-gray-400 rounded-full" />
              <span className="text-sm text-neutral-500">{t('common.noActiveQueries')}</span>
            </div>
          </div>
        </Card>
        <Card title={t('common.qualityIndicators')}>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">{t('common.queryAccuracy')}</span>
                <span className="text-sm text-green-600 font-semibold">98%</span>
              </div>
              <div className="w-full bg-neutral-200 dark:bg-neutral-700 rounded-full h-2">
                <div className="bg-green-500 h-2 rounded-full" style={{ width: '98%' }} />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">{t('common.systemHealth')}</span>
                <span className="text-sm text-green-600 font-semibold">96%</span>
              </div>
              <div className="w-full bg-neutral-200 dark:bg-neutral-700 rounded-full h-2">
                <div className="bg-green-500 h-2 rounded-full" style={{ width: '96%' }} />
              </div>
            </div>
          </div>
        </Card>
      </section>

      {/* Recent Activity Section */}
      <section className="grid gap-4 lg:grid-cols-2">
        <Card title={t('dashboard.suggestions.title')} description={t('common.basedOnRecent')}>
          <div className="space-y-2">
            <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-md">
              <p className="text-sm font-medium text-neutral-900 dark:text-white">
                {t('common.suggestion1')}
              </p>
            </div>
            <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-md">
              <p className="text-sm font-medium text-neutral-900 dark:text-white">
                {t('common.suggestion2')}
              </p>
            </div>
          </div>
        </Card>
        <Card title={t('dashboard.recentQueries.title') || 'Recent Queries'} description={t('common.lastQueries') || 'Your latest queries'}>
          {historyLoading ? (
            <SkeletonCard />
          ) : recentQueries?.items && recentQueries.items.length > 0 ? (
            <div className="space-y-2">
              {recentQueries.items.slice(0, 5).map((query: any) => (
                <div 
                  key={query.id} 
                  className="flex items-start justify-between gap-2 cursor-pointer hover:bg-neutral-50 dark:hover:bg-neutral-800 p-2 rounded"
                  onClick={() => navigate(`/query/${query.id}`)}
                >
                  <div className="flex-1">
                    <p className="text-sm font-medium text-neutral-900 dark:text-white truncate">
                      {query.question || query.sql?.substring(0, 50) + '...'}
                    </p>
                    <p className="text-xs text-neutral-500">
                      {new Date(query.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded ${
                    query.status === 'success' || !query.status
                      ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300'
                      : 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300'
                  }`}>
                    {query.status || 'success'}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-neutral-500">No recent queries</p>
          )}
        </Card>
      </section>
    </div>
  )
}
