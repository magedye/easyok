import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useNavigate } from 'react-router-dom'
import { Card } from '@/components/shared/Card'
import { Button } from '@/components/shared/Button'
import { useTranslation } from 'react-i18next'
import { getQueryHistory, deleteQuery } from '@/services/queryService'
import { SkeletonTable } from '@/components/loading/SkeletonCard'

export const HistoryPage = () => {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const [filter, setFilter] = useState<'all' | 'success' | 'failed'>('all')

  const { data: history, isLoading } = useQuery({
    queryKey: ['query-history', filter],
    queryFn: () => getQueryHistory(),
  })

  const deleteMutation = useMutation({
    mutationFn: deleteQuery,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['query-history'] })
    },
  })

  const filteredQueries = history?.items?.filter((q: any) => {
    if (filter === 'all') return true
    if (filter === 'success') return q.status === 'success' || !q.status
    if (filter === 'failed') return q.status === 'failed' || q.status === 'error'
    return true
  }) || []

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-neutral-900 dark:text-white mb-2">
            {t('history.title') || 'Query History'}
          </h1>
          <p className="text-neutral-500 dark:text-neutral-400">
            {t('history.subtitle') || 'Browse your past queries'}
          </p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant={filter === 'all' ? 'primary' : 'secondary'} 
            onClick={() => setFilter('all')}
          >
            All
          </Button>
          <Button 
            variant={filter === 'success' ? 'primary' : 'secondary'} 
            onClick={() => setFilter('success')}
          >
            Success
          </Button>
          <Button 
            variant={filter === 'failed' ? 'primary' : 'secondary'} 
            onClick={() => setFilter('failed')}
          >
            Failed
          </Button>
        </div>
      </div>

      <Card title="Recent Queries">
        {isLoading ? (
          <SkeletonTable rows={10} />
        ) : filteredQueries.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-neutral-200 dark:border-neutral-700">
                  <th className="text-left text-sm font-semibold text-neutral-900 dark:text-white py-3 px-4">
                    {t('history.columns.date') || 'Date'}
                  </th>
                  <th className="text-left text-sm font-semibold text-neutral-900 dark:text-white py-3 px-4">
                    {t('history.columns.query') || 'Query'}
                  </th>
                  <th className="text-left text-sm font-semibold text-neutral-900 dark:text-white py-3 px-4">
                    {t('history.columns.status') || 'Status'}
                  </th>
                  <th className="text-left text-sm font-semibold text-neutral-900 dark:text-white py-3 px-4">
                    {t('history.columns.duration') || 'Duration'}
                  </th>
                  <th className="text-left text-sm font-semibold text-neutral-900 dark:text-white py-3 px-4">
                    {t('history.columns.rows') || 'Rows'}
                  </th>
                  <th className="text-left text-sm font-semibold text-neutral-900 dark:text-white py-3 px-4">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredQueries.map((q: any) => (
                  <tr 
                    key={q.id} 
                    className="border-b border-neutral-200 dark:border-neutral-700 hover:bg-neutral-50 dark:hover:bg-neutral-800 cursor-pointer"
                    onClick={() => navigate(`/query/${q.id}`)}
                  >
                    <td className="py-3 px-4 text-sm text-neutral-500">
                      {new Date(q.createdAt).toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-sm text-neutral-900 dark:text-white font-mono truncate max-w-xs">
                      {q.question || q.sql?.substring(0, 60) + '...'}
                    </td>
                    <td className="py-3 px-4 text-sm">
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        q.status === 'success' || !q.status
                          ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300'
                          : 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300'
                      }`}>
                        {q.status || 'success'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-sm text-neutral-900 dark:text-white">
                      {q.executionTime || 0}ms
                    </td>
                    <td className="py-3 px-4 text-sm text-neutral-900 dark:text-white">
                      {q.rowCount || 0}
                    </td>
                    <td className="py-3 px-4 text-sm">
                      <Button
                        variant="secondary"
                        className="text-xs py-1 px-2"
                        onClick={(e) => {
                          e.stopPropagation()
                          if (confirm('Delete this query?')) {
                            deleteMutation.mutate(q.id)
                          }
                        }}
                        disabled={deleteMutation.isPending}
                      >
                        Delete
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-neutral-500 dark:text-neutral-400 mb-4">
              No queries found
            </p>
            <Button variant="primary" onClick={() => navigate('/dashboard')}>
              Create Your First Query
            </Button>
          </div>
        )}
      </Card>
    </div>
  )
}
